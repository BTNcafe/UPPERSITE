// get test href.
console.log(HREF('Test'));

// get TestBox's test href.
console.log(TestBox.HREF('Test'));
