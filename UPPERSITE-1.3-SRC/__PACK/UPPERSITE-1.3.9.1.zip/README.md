![ScreenShot](http://1.3.uppercase.io/UPPERCASE.IO.OfficialSite/R/UPPERSITE/logo.png)
=========
UPPERSITE는 BTNcafe에서 개발한 웹 사이트를 개발하는데 필요한 전 범위를 아우르는 Full Stack 프레임워크입니다.

Version
-------
1.3.9.1

Based On
--------
- JavaScript 1.5 (ECMA-262, 3rd edition)
- CommonJS Modules/1.0

Server-side:
- Node.js (http://nodejs.org)
- MongoDB (http://www.mongodb.org)
- ImageMagick (http://www.imagemagick.org)

License
-------
UPPERSITE의 License는 이하 문서를 따릅니다.
https://github.com/BTNcafe/UPPERSITE/blob/master/LICENSE.md

Contact
-------
- Official Web Site: http://UPPERCASE.IO/#UPPERSITE
- UPPERSITE: https://github.com/BTNcafe/UPPERSITE

2014 ⓒ BTNcafe · http://www.btncafe.com · contact@btncafe.com
